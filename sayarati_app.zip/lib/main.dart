
import 'package:flutter/material.dart';

void main() {
  runApp(SayaratiApp());
}

class SayaratiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'سيارتي',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
        fontFamily: 'Roboto',
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('تطبيق سيارتي'),
      ),
      body: Center(
        child: Text(
          'مرحبًا بك في تطبيق سيارتي\nبإعداد احترافي وواجهة عربية بالكامل',
          style: TextStyle(fontSize: 20),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
